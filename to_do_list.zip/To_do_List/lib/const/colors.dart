import 'package:flutter/material.dart';

Color custom_green = const Color(0xff18DAA3);
Color backgroundColors = Colors.grey.shade100;